//smooth scrolling

const scrolltoTop = document.querySelector(".scrolltoTop");
const nav_bar = document.querySelector(".nav-bar");
const scrollTop = () => {
  nav_bar.scrollIntoView({
    behavior: "smooth",
  });
};
// scrolltoTop.addEventListener('click',scrollTop())

//navbar styling
var main_navbar = document.querySelector(".nav-bar");
var navbar_list = document.querySelector(".navbar-list");
window.onscroll = function () {
  myfunction();
};
// const sticky =main_navbar.offsetTop;

function myfunction() {
  if (window.pageYOffset >= navbar_list.offsetTop) {
    main_navbar.classList.add("sticky");
  } else {
    main_navbar.classList.remove("sticky");
  }
}

//Mobile view
const mobileNavbar = document.querySelector(".mobile-navbar");
const nav_header = document.querySelector(".nav-bar");
const toggleNavbar = () => {
  // console.log('hi');
  nav_header.classList.toggle("active");
};

// mobileNavbar.addEventListener("click", toggleNavbar);

// dark mode

// const dark_icon = document.querySelector(".dark-icon");
// const container = document.querySelector(".container");
// const lightIcon = document.querySelector(".light-icon");
// dark_icon.addEventListener("click", () => {
//   container.classList.toggle("dark-mode-on");
//   dark_icon.classList.toggle("hide");
//   lightIcon.classList.toggle("hide");
// });
// lightIcon.addEventListener("click", () => {
//   container.classList.toggle("dark-mode-on");
//   dark_icon.classList.toggle("hide");
//   lightIcon.classList.toggle("hide");
// });

//skill part

const education = document.querySelector(".education");
const skills = document.querySelector(".skills");
const eduDetails = document.querySelector(".education-details");
var tablinks = document.getElementsByClassName('tab-link');
var tabcontents = document.getElementsByClassName("table-content");
var skillDetails = document.querySelector(".skills-details");

//

function opentab(tabname){
  for(x of tablinks){
    x.classList.remove('active-link');
  }
  for(x of tabcontents){
    x.classList.remove('active-tab');
  }
  document.addEventListener('click', function(event){
    event.target.classList.add('active-link');k
  })
  document.getElementById(tabname).classList.add('active-tab');
  
}


const hamburger = document.querySelector('.hamburger');
hamburger.addEventListener('click', function(){
  let navBar = document.querySelector('.nav-bar');
  navBar.classList.toggle('active');
});